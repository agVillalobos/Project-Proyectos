# How to create a Serverless REST API with MongoDB
A quick and easy guide of how to hook up a single Serverless service with basic CRUD interaction.